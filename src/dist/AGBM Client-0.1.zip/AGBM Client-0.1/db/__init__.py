"""Модуль классов для работы с базой данных."""


from .client_db import ClientDatabase, MessageType
from .storage import Base, ServerStorage
